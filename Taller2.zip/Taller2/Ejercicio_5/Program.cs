﻿namespace Ejercicio_5 {
    internal class Program {
        static void Main(string[] args) {
            int totalMuestrasElefantes = 3;
            int totalMuestrasJirafas = 2;
            int totalMuestrasChimpances = 4;


            int ElefantesC = 0;
            int JirafasC = 0;
            int ChimpancesC = 0;

            for (int i = 0; i < totalMuestrasElefantes; i++)
            {
                Console.WriteLine($"Ingresa la edad del elefante {i + 1}:");
                int edad= Convert.ToInt32( Console.ReadLine() );

                if (edad >= 0 && edad <= 1)
                {
                    ElefantesC++;
                }
                else if (edad > 1 && edad < 3)
                {
                    JirafasC++;
                }
                else if (edad >= 3)
                {
                    ChimpancesC++;
                }
            }
            double porcentajeEdad0a1Elefantes = (double) ElefantesC/ totalMuestrasElefantes * 100;
            double porcentajeEdad1a3Jirafas = (double)JirafasC / totalMuestrasJirafas * 100;
            double porcentajeEdad3masChimpances = (double)ChimpancesC / totalMuestrasChimpances * 100;

            Console.WriteLine($"Porcentaje de elefantes de 0 a 1 año: {porcentajeEdad0a1Elefantes}%");
            Console.WriteLine($"Porcentaje de jirafas de más de 1 año y menos de 3: {porcentajeEdad1a3Jirafas}%");
            Console.WriteLine($"Porcentaje de chimpancés de 3 o más años: {porcentajeEdad3masChimpances}%");


        }
    }
}
