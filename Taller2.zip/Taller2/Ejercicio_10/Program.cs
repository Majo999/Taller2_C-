﻿
internal class Program {
    static void Main(string[] args) {

        Console.WriteLine("Escribe el peso de la carta");
        double peso = double.Parse(Console.ReadLine());

        Console.WriteLine("Escribe el tipo de envío (corriente y recomendado)");
        string tipoEnvio = Console.ReadLine();

        Console.WriteLine("Escribe el destino (local, nacional e internacional)");
        string destino = Console.ReadLine();

        int tarifa = 0;

        if (tipoEnvio == "corriente")
        {
            if (destino == "local") tarifa = 100;
            else if (destino == "nacional") tarifa = 150;
            else if (destino == "internacional") tarifa = 200;
            else
            {
                Console.WriteLine("Escribe un destino válido");
                return;
            };
        }
        else if (tipoEnvio == "recomendado")
        {
            if (destino == "local") tarifa = 200;
            else if (destino == "nacional") tarifa = 300;
            else if (destino == "internacional") tarifa = 400;
            else
            {
                Console.WriteLine("Escribe un destino válido");
                return;
            };
        }
        else
        {
            Console.WriteLine("Escribe un tipo de envío válido");
            return;

        }


        double precioPorGramo = peso * tarifa;
        double precioTotal = precioPorGramo * (precioPorGramo * 0.16);

        Console.WriteLine("El valor total a pagar es de {0}", precioTotal);


    }
}

