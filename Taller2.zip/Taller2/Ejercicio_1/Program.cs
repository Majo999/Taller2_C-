﻿namespace Ejercicio_1 {
    internal class Program {
        static void Main(string[] args) {
            int[] votos = [1,2,3,3,2,1,2,3,1];
            double cantidadV = votos.Length;
            int candidato_uno = 0;
            int candidato_dos = 0;
            int candidato_tres = 0;

            foreach (int i in votos)
            {
                if (i == 1)
                {
                    candidato_uno++;
                }else if(i == 2)
                {
                    candidato_dos++;
                }
                else
                {
                    candidato_tres++;
                }
            }
            if (candidato_uno > candidato_dos && candidato_uno > candidato_tres)
            {
                Console.WriteLine("El ganador es el candidato #1 con:" + candidato_uno + "votos");
            }
            else if (candidato_dos > candidato_uno && candidato_dos > candidato_tres)
            {
                Console.WriteLine("El ganador es el candidato #2 con:" + candidato_dos + "votos");
            }
            else if(candidato_tres > candidato_uno && candidato_tres > candidato_dos)
            {
                Console.WriteLine("El ganador es el candidato #3 con:" + candidato_tres + "votos\n");
            }

            double porcentaje_uno = (candidato_uno/ cantidadV) * 100;
            double porcentaje_dos = (candidato_dos / cantidadV) * 100;
            double porcentaje_tres = (candidato_tres / cantidadV) * 100;


            Console.WriteLine("Promedio de punto-------\n");
            Console.WriteLine("\n Porcentaje Candidato #1: \n"+porcentaje_uno+ "% \n Votos: \n"+ candidato_uno);
            Console.WriteLine("\n Porcentaje Candidato #2: \n" + porcentaje_dos+ "% \n Votos: \n" + candidato_dos);
            Console.WriteLine("\n Porcentaje Candidato #3: \n" + porcentaje_tres+ "% \n Votos: \n" + candidato_tres);


        }
    }
}
