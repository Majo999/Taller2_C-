﻿namespace Ejercicio_8 {
    internal class Program {
        static void Main(string[] args) {
            int cantidadCalificaciones = 3;
            int calificacionesAprobatorias = 0;

            for (int i = 0; i < cantidadCalificaciones; i++)
            {
                Console.WriteLine("Ingrese la calificación del alumno " + (i + 1) + ":");
                int calificacion = Convert.ToInt32(Console.ReadLine());

                if (calificacion >= 70)
                {
                    calificacionesAprobatorias++;
                }
            }

            double porcentajeReprobados = ((double)(cantidadCalificaciones - calificacionesAprobatorias) / cantidadCalificaciones) * 100;

            Console.WriteLine("El porcentaje de reprobados es: " + porcentajeReprobados.ToString("0.00") + "%");

        }
    }
}
