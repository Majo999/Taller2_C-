﻿namespace Ejercicio_3 {
    internal class Program {
        static void Main(string[] args) {
            int clientes = 2;
            double ingresoT = 0;
            for (int i = 0; i < clientes; i++)
            {
                Console.WriteLine("¿Cuantos kilos desea compara?");
                double compraK = Convert.ToDouble(Console.ReadLine());

                if (compraK <= 0)
                {
                    return;
                }
                Console.WriteLine("¿Cuanto cuesta el kilo?");
                double precioK = Convert.ToDouble(Console.ReadLine());

                if (precioK <= 0)
                {
                    return;
                }

                if (compraK > 10)
                {
                    double compra = compraK * precioK;
                    double descuento = compra * 0.15;
                    double resultDesc = compra - descuento;
                    Console.WriteLine("Ha recibido descuento del 15% \n Usted pagará: " + resultDesc);
                    ingresoT += resultDesc;
                }
                else if (compraK <= 10)
                {
                    double resultado = compraK * precioK;
                    Console.WriteLine("Usted pagará: " + resultado);
                    ingresoT += resultado;

                }
            }
            Console.WriteLine("En total la tienda ha recibido" + "$" + ingresoT);
        }

    }
}

