﻿namespace Ejercicio_7 {
    internal class Program {
        static void Main(string[] args) {
            int[] niños = [12, 3, 4, 5, 11, 0, 10, 9, 8];
            int[] jovenes = [14, 13, 15, 16, 17, 18, 19, 20];
            int[] adultos = [21, 22, 23, 24, 25, 29, 30, 26];
            int[] viejos = [59, 60, 70, 75, 79, 64,];

            int niñosP = 0;
            int jovenesP = 0;
            int adultosP = 0;
            int viejosP = 0;

            for (int i = 0; i < niños.Length - 1; i++)
            {
                niñosP += niños[i];
            }
            for (int i = 0; i <= jovenes.Length - 1; i++)
            {
                jovenesP += jovenes[i];
            }
            for (int i = 0; i <= adultos.Length - 1; i++)
            {
                adultosP += adultos[i];
            }
            for (int i = 0; i <= viejos.Length - 1; i++)
            {
                viejosP += viejos[i];
            }

            int niñosProm = niñosP / niños.Length;
            int jovenesProm = jovenesP / jovenes.Length;
            int adultosProm = adultosP / adultos.Length;
            int viejosProm = viejosP / viejos.Length;


            Console.WriteLine("Promedio peso por edades------------\n");
            Console.WriteLine("Niños: " + niñosProm + "Kg" + "\n");
            Console.WriteLine("Niños: " + niñosProm + "Kg" + "\n");
            Console.WriteLine("Niños: " + niñosProm + "Kg" + "\n");
            Console.WriteLine("Niños: " + niñosProm + "Kg" + "\n");
        }
    }
}
